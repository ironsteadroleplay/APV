# Douanegebieden

In de volgende douanegebieden mag er preventief gefouillerd worden op personen, goederen en voertuigen door de Koninklijke Marechaussee en de Politie.

## Kaartweergave

![Kaart](img/douanegebieden.webp)