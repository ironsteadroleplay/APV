# Wetgeving Springbank Roleplay

Welkom bij de wet- en regelgeving van Springbank Roleplay. De verschillende documenten die onze wet- en regelgeving omvat zijn opgesteld om de speelervaring voor iedereen zo leuk mogelijk te houden.

Het is zaak dat iedereen die deelneemt aan Springbank op de hoogte is van de regels en wetten.

De volgende documenten worden behandeld op deze website:

- De APV is een verzameling van regels en richtlijnen die te maken hebben met zaken buiten roleplay.
- Het wetboek van Springbank omvat alle wetten in de roleplay.
- De overige documenten zijn van toepassing op verschillende in-game zaken, zoals voertuigeisen en dergelijke.

## Officiële discord servers

| *Titel* | *Omschrijving* | *Uitnodiging* |
|---|---|:---:|
|Springbank Roleplay| Discord server van Springbank Roleplay | [Klik hier](https://discord.gg/springbankrp) |
|Springbank Support| Alle support gerelateerde zaken worden hier geregeld | [Klik hier](https://discord.gg/phj2fGkqvF) |
|Springbank Bedrijven| Officiële particuliere bedrijven binnen Springbank | [Klik hier](https://discord.gg/ddtsmy9amq) |
|Springbank Vliegschool| Officiële vliegschool van Springbank | [Klik hier](https://discord.gg/7AnPp5ayY3) |
|Springbank Overheid| Verzamelplaats van alle overheidsorganisaties | [Klik hier](https://discord.gg/FTZv2yMWE5) |