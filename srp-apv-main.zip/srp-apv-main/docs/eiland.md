# Eilandregelgeving

De volgende regelgeving is alleen van toepassing op het eiland van Springbank Roleplay. Alle wetten opgenomen in het wetboek zijn ook van toepassing op het eiland maar er is geen handhaving van deze wetten.
LET OP: het verlengde land hoort hier niet bij (Rexwood). Die valt onder het gewone APV! 

## Aanvullende regelgeving eiland


### Artikel 1 - Jurisdictie

1. Politie, KMAR en speciale diensten hebben geen bevoegdheden op het eiland en treden hier niet op.
2. Uitzondering op lid 1 is: Indien een achtervolging buiten het eiland is begonnen en de betrokken persoon het eiland op vlucht, mogen deze diensten de achtervolging voortzetten binnen of rond het eiland.

### Artikel 2 - Campen

1. Het is niet toegestaan om actieve drugs locaties te campen om hier voordeel uit te behalen, bijvoorbeeld door te wachten op iemand om te beroven.
2. Het is wel toegestaan om bij de wapendealer NPC te campen.

### Artikel 3 - Rippen

1. Rippen en handsuppen is op het gehele eiland toegestaan
